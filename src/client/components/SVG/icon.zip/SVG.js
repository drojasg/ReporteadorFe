import React, { Component } from "react";
import sprite from'./icons.svg';

export default class SVG extends Component {
    constructor(props) {
        super(props);
        this.state = {
            hotelData: JSON.parse(localStorage.getItem('hotel')),
        }
    }

    componentDidMount(){
        // this.setState({ load: true });
        console.log("icon: ", this.props);
    }

    render(){
        /** Implementacion component icon svg
         * <SVG width={'40px'} height={'40px'} color={'#11ae92'} icon={'video_games'}/>
         */
        return(
            <div>
                <svg style={{width: this.props.width, height: this.props.height, fill: this.props.color}}>
                    <use xlinkHref={`${sprite}#${this.props.icon}`}></use>
                </svg>
            </div>
        );
    }
}